
import java.util.regex.Pattern;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Jana
 */
public class InputValidator {
    public static boolean isValidInput(String input) {
        
        return input != null && !input.isEmpty();
        
}
    
    private static final String PHONE_NUMBER_PATTERN = "\\d{3}-\\d{3}-\\d{4}";

    public static boolean isValidPhoneNumber(String phoneNumber) {
        return Pattern.matches(PHONE_NUMBER_PATTERN, phoneNumber);
}
}
